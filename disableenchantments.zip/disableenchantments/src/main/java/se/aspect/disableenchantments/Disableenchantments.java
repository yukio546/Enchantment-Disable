package se.aspect.disableenchantments;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class Disableenchantments extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {

        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {

    }

    @EventHandler
    public void onEnchantItem(EnchantItemEvent event) {
        Player player = event.getEnchanter();
        if (!player.isOp()) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "Enchanting is disabled for non-operators.");
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player) {
            Player player = (Player) event.getWhoClicked();
            if (!player.isOp()) {
                ItemStack currentItem = event.getCurrentItem();
                ItemStack cursorItem = event.getCursor();
                InventoryType.SlotType slotType = event.getSlotType();

                if (event.isShiftClick()) {
                    ItemStack shiftItem = event.getCurrentItem();
                    if (shiftItem != null && shiftItem.hasItemMeta() && shiftItem.getItemMeta().hasEnchants()) {
                        if (isArmor(shiftItem)) {
                            event.setCancelled(true);
                            player.sendMessage(ChatColor.RED + "Equipping enchanted armor is disabled for non-operators.");
                            return;
                        }
                    }
                }

                // Prevent clicking in armor slots with enchanted armor
                if (currentItem != null && currentItem.hasItemMeta() && currentItem.getItemMeta().hasEnchants()) {
                    if (slotType == InventoryType.SlotType.ARMOR) {
                        event.setCancelled(true);
                        player.sendMessage(ChatColor.RED + "Equipping enchanted armor is disabled for non-operators.");
                    }
                    return;
                }

                if (cursorItem != null && cursorItem.hasItemMeta() && cursorItem.getItemMeta().hasEnchants()) {
                    if (slotType == InventoryType.SlotType.ARMOR) {
                        event.setCancelled(true);
                        player.sendMessage(ChatColor.RED + "Equipping enchanted armor is disabled for non-operators.");
                    }
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player) {
            Player player = (Player) event.getWhoClicked();
            if (!player.isOp()) {
                for (int slot : event.getRawSlots()) {
                    if (slot >= 5 && slot <= 8) { // Armor slots
                        ItemStack draggedItem = event.getOldCursor();
                        if (draggedItem != null && draggedItem.hasItemMeta() && draggedItem.getItemMeta().hasEnchants()) {
                            event.setCancelled(true);
                            player.sendMessage(ChatColor.RED + "Equipping enchanted armor is disabled for non-operators.");
                            return;
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!player.isOp()) {
            ItemStack item = player.getInventory().getItemInMainHand();
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasEnchants()) {
                event.setCancelled(true);
                player.sendMessage(ChatColor.RED + "Using enchanted items is disabled for non-operators.");
            }
        }
    }

    @EventHandler
    public void onPlayerSwapHandItems(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (!player.isOp()) {
            ItemStack item = event.getOffHandItem();
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasEnchants()) {
                event.setCancelled(true);
                player.sendMessage(ChatColor.RED + "Swapping enchanted items is disabled for non-operators.");
            }
        }
    }

    @EventHandler
    public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        if (!player.isOp()) {
            ItemStack item = event.getItem();
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasEnchants()) {
                event.setCancelled(true);
                player.sendMessage(ChatColor.RED + "Consuming enchanted items is disabled for non-operators.");
            }
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player) {
            Player player = (Player) event.getDamager();
            if (!player.isOp()) {
                ItemStack item = player.getInventory().getItemInMainHand();
                if (item != null && item.hasItemMeta() && item.getItemMeta().hasEnchants()) {
                    event.setCancelled(true);
                    player.sendMessage(ChatColor.RED + "Using enchanted weapons is disabled for non-operators.");
                }
            }
        }
    }

    @EventHandler
    public void onEntityPickupItem(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();
            ItemStack item = event.getItem().getItemStack();
            if (!player.isOp() && item.hasItemMeta() && item.getItemMeta().hasEnchants()) {
                player.sendMessage(ChatColor.RED + "You picked up an enchanted item. Using it is disabled for non-operators.");
            }
        }
    }

    @EventHandler
    public void onPlayerArmorEquip(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player) {
            Player player = (Player) event.getWhoClicked();
            if (!player.isOp()) {
                ItemStack currentItem = event.getCurrentItem();
                InventoryType.SlotType slotType = event.getSlotType();

                if (slotType == InventoryType.SlotType.ARMOR && currentItem != null && currentItem.hasItemMeta() && currentItem.getItemMeta().hasEnchants()) {
                    event.setCancelled(true);
                    player.getInventory().addItem(currentItem);
                    event.setCurrentItem(null);
                    player.sendMessage(ChatColor.RED + "Equipping enchanted armor is disabled for non-operators.");
                }
            }
        }
    }

    private boolean isArmor(ItemStack item) {
        switch (item.getType()) {
            case LEATHER_HELMET:
            case LEATHER_CHESTPLATE:
            case LEATHER_LEGGINGS:
            case LEATHER_BOOTS:
            case CHAINMAIL_HELMET:
            case CHAINMAIL_CHESTPLATE:
            case CHAINMAIL_LEGGINGS:
            case CHAINMAIL_BOOTS:
            case IRON_HELMET:
            case IRON_CHESTPLATE:
            case IRON_LEGGINGS:
            case IRON_BOOTS:
            case DIAMOND_HELMET:
            case DIAMOND_CHESTPLATE:
            case DIAMOND_LEGGINGS:
            case DIAMOND_BOOTS:
            case GOLDEN_HELMET:
            case GOLDEN_CHESTPLATE:
            case GOLDEN_LEGGINGS:
            case GOLDEN_BOOTS:
            case NETHERITE_HELMET:
            case NETHERITE_CHESTPLATE:
            case NETHERITE_LEGGINGS:
            case NETHERITE_BOOTS:
                return true;
            default:
                return false;
        }
    }
}
